/**
 * Basic sanity test to verify Jest is working
 */

describe('WatchLockAI Test Suite', () => {
  test('Jest is configured correctly', () => {
    expect(true).toBe(true);
  });

  test('Basic arithmetic works', () => {
    expect(2 + 2).toBe(4);
  });
});
